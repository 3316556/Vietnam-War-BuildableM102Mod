﻿# Configure Buildable M102 Howitzer

No user configuration is required. Build the matching artillery emplacement from the normal build menu.

## MelonPreferences

Most mods create preferences automatically only if they need them. If this mod uses MelonPreferences, the settings will appear after the game has launched once with the mod installed.

Preference file location:

~~~text
VietnamWar\UserData\MelonPreferences.cfg
~~~

Do not ship a pre-filled MelonPreferences.cfg to users; it can overwrite settings from other mods.
